/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package login015;

/**
 *
 * @author shafa_ssa
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Login015 {
    public static Connection con;
    public static Statement stm;
    public static void main(String args[]){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String database ="jdbc:mysql://127.0.0.1/login";
            String username="root";
            String pass="";
            con =DriverManager.getConnection(database, username, pass);
            stm = con.createStatement();
            System.out.println("koneksi berhasil");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("koneksi gagal" +e.getMessage());
        }
    }
    
}

